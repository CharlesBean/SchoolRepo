/**
 * \file TileVisitor.cpp
 *
 * \author Charles Bean
 */

#include "stdafx.h"
#include "TileVisitor.h"


CTileVisitor::CTileVisitor()
{
}


CTileVisitor::~CTileVisitor()
{
}
