/**
 * \file BuildingCounter.cpp
 *
 * \author Charles Bean
 */

#include "stdafx.h"
#include "BuildingCounter.h"


CBuildingCounter::CBuildingCounter()
{
}


CBuildingCounter::~CBuildingCounter()
{
}

