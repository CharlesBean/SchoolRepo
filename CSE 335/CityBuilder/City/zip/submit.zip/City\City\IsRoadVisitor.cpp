#include "stdafx.h"
#include "IsRoadVisitor.h"


CIsRoadVisitor::CIsRoadVisitor()
{
}


CIsRoadVisitor::~CIsRoadVisitor()
{
}
