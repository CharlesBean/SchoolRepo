/**
 * \file ActorFactory.cpp
 *
 * \author Charles Bean
 */

#include "stdafx.h"
#include "ActorFactory.h"

/** \brief Constructor */
CActorFactory::CActorFactory()
{
}

/** \brief Destructor */
CActorFactory::~CActorFactory()
{
}
